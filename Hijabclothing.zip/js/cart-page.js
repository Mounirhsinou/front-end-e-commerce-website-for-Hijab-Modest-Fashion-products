/**
 * Cart Page Logic
 * Handles rendering of cart items and interactions on the cart page.
 */

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('cart-items-container');
    const emptyMsg = document.getElementById('empty-cart-msg');
    const cartContent = document.getElementById('cart-content');
    const subtotalEl = document.getElementById('cart-subtotal');
    const totalEl = document.getElementById('cart-total');

    function renderCart() {
        const items = Cart.items;

        if (items.length === 0) {
            emptyMsg.style.display = 'block';
            cartContent.style.display = 'none';
            return;
        }

        emptyMsg.style.display = 'none';
        cartContent.style.display = 'grid';

        container.innerHTML = items.map(item => `
            <div class="cart-item flex mb-md" style="gap: var(--spacing-md); border-bottom: 1px solid var(--color-border); padding-bottom: var(--spacing-md);">
                <div class="cart-item-image" style="width: 100px; aspect-ratio: 3/4; background: var(--color-bg-secondary); border-radius: var(--border-radius-sm); overflow: hidden;">
                    <img src="${item.image}" alt="${item.name}" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <div class="cart-item-details flex flex-col justify-between" style="flex: 1;">
                    <div>
                        <h3 style="font-size: var(--font-size-lg); margin-bottom: 0.25rem;">
                            <a href="product-${item.id}.html">${item.name}</a>
                        </h3>
                        <p style="color: var(--color-text-muted); font-size: var(--font-size-sm);">$${item.price.toFixed(2)}</p>
                    </div>
                    <div class="flex justify-between items-center">
                        <div class="flex items-center" style="gap: 0.5rem;">
                            <button class="btn btn-secondary" style="padding: 0.25rem 0.5rem;" onclick="updateItemQty('${item.id}', ${item.quantity - 1})">-</button>
                            <span style="width: 30px; text-align: center;">${item.quantity}</span>
                            <button class="btn btn-secondary" style="padding: 0.25rem 0.5rem;" onclick="updateItemQty('${item.id}', ${item.quantity + 1})">+</button>
                        </div>
                        <button class="btn btn-ghost" style="color: var(--color-error);" onclick="removeItem('${item.id}')">Remove</button>
                    </div>
                </div>
            </div>
        `).join('');

        const total = Cart.getTotal();
        subtotalEl.textContent = `$${total.toFixed(2)}`;
        totalEl.textContent = `$${total.toFixed(2)}`;
    }

    // Expose functions to global scope for onclick handlers
    window.updateItemQty = (id, newQty) => {
        Cart.updateQuantity(id, newQty);
        renderCart();
    };

    window.removeItem = (id) => {
        Cart.remove(id);
        renderCart();
    };

    // Listen for updates from other tabs/windows
    window.addEventListener('storage', () => {
        Cart.load();
        renderCart();
    });

    // Initial render
    renderCart();
});
