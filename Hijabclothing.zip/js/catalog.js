/**
 * Catalog Logic
 * Handles filtering, sorting, and rendering the product grid.
 */

document.addEventListener('DOMContentLoaded', async () => {
    const grid = document.getElementById('product-grid');
    const noResults = document.getElementById('no-results');
    const filterCategory = document.getElementById('filter-category');
    const filterColor = document.getElementById('filter-color');
    const sortPrice = document.getElementById('sort-price');
    const clearBtn = document.getElementById('clear-filters');

    let allProducts = await Products.fetchAll();
    let currentProducts = [...allProducts];

    // Check URL params for initial filter
    const urlParams = new URLSearchParams(window.location.search);
    const initialCategory = urlParams.get('category');

    if (initialCategory) {
        // If it's a special category like "New" or "Best", we might handle differently
        // For now, just map to the select if it exists
        if (Array.from(filterCategory.options).some(opt => opt.value === initialCategory)) {
            filterCategory.value = initialCategory;
        }
    }

    function filterAndRender() {
        const category = filterCategory.value;
        const color = filterColor.value;
        const sort = sortPrice.value;

        // Filter
        currentProducts = allProducts.filter(p => {
            const matchCategory = !category || p.category === category;
            const matchColor = !color || p.colors.some(c => c.includes(color));
            return matchCategory && matchColor;
        });

        // Sort
        if (sort === 'low-high') {
            currentProducts.sort((a, b) => a.price - b.price);
        } else if (sort === 'high-low') {
            currentProducts.sort((a, b) => b.price - a.price);
        } else {
            // Default: sort by ID or original order
            currentProducts.sort((a, b) => a.id.localeCompare(b.id));
        }

        // Render
        if (currentProducts.length > 0) {
            Products.renderGrid('product-grid', currentProducts);
            noResults.style.display = 'none';
            grid.style.display = 'grid';
        } else {
            grid.style.display = 'none';
            noResults.style.display = 'block';
        }
    }

    // Event Listeners
    filterCategory.addEventListener('change', filterAndRender);
    filterColor.addEventListener('change', filterAndRender);
    sortPrice.addEventListener('change', filterAndRender);

    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            filterCategory.value = '';
            filterColor.value = '';
            sortPrice.value = 'default';
            filterAndRender();
        });
    }

    // Initial Render
    filterAndRender();
});
