/**
 * UI Interactions
 * Handles Dark Mode, Mobile Menu, and other global UI events.
 */

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initMobileMenu();
    initCookieConsent();
});

/* =========================================
   THEME TOGGLE (Dark Mode)
   ========================================= */
function initTheme() {
    const themeCheckbox = document.getElementById('theme-toggle-checkbox');

    // Check for saved user preference, if any, on load of the website
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        if (themeCheckbox) themeCheckbox.checked = true;
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        if (themeCheckbox) themeCheckbox.checked = false;
    }

    if (themeCheckbox) {
        themeCheckbox.addEventListener('change', (e) => {
            const newTheme = e.target.checked ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
}

/* =========================================
   MOBILE MENU
   ========================================= */
function initMobileMenu() {
    const menuBtn = document.getElementById('mobile-menu-btn');
    const navLinks = document.getElementById('nav-links');

    if (menuBtn && navLinks) {
        menuBtn.addEventListener('click', () => {
            const isExpanded = menuBtn.getAttribute('aria-expanded') === 'true';
            menuBtn.setAttribute('aria-expanded', !isExpanded);
            navLinks.classList.toggle('open');
        });
    }
}

/* =========================================
   COOKIE CONSENT
   ========================================= */
function initCookieConsent() {
    const consentKey = 'cookie_consent';
    if (!localStorage.getItem(consentKey)) {
        showCookieBanner();
    }

    function showCookieBanner() {
        const banner = document.createElement('div');
        banner.id = 'cookie-banner';
        banner.className = 'fade-in';
        banner.style.cssText = `
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background-color: var(--color-bg-card);
            border-top: 1px solid var(--color-border);
            padding: var(--spacing-md);
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: var(--spacing-md);
        `;

        banner.innerHTML = `
            <p style="margin: 0; max-width: 800px;">
                We use cookies to improve your experience. By continuing to use this site, you agree to our <a href="cookies.html" style="text-decoration: underline;">Cookie Policy</a>.
            </p>
            <div class="flex" style="gap: var(--spacing-sm);">
                <button id="accept-cookies" class="btn btn-primary">Accept</button>
                <button id="decline-cookies" class="btn btn-secondary">Decline</button>
            </div>
        `;

        document.body.appendChild(banner);

        document.getElementById('accept-cookies').addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            banner.remove();
        });

        document.getElementById('decline-cookies').addEventListener('click', () => {
            localStorage.setItem(consentKey, 'declined');
            banner.remove();
        });
    }
}
