/**
 * Cart Logic
 * Handles adding, removing, updating, and persisting cart items.
 */

const CART_STORAGE_KEY = 'hijab_cart';

const Cart = {
    items: [],

    init() {
        this.load();
        this.updateIcon();
    },

    load() {
        const stored = localStorage.getItem(CART_STORAGE_KEY);
        if (stored) {
            try {
                this.items = JSON.parse(stored);
            } catch (e) {
                console.error('Failed to parse cart data', e);
                this.items = [];
            }
        }
    },

    save() {
        localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(this.items));
        this.updateIcon();
        // Dispatch event for other components to listen
        window.dispatchEvent(new CustomEvent('cart-updated', { detail: this.items }));
    },

    add(product, quantity = 1, variant = null) {
        const existingItemIndex = this.items.findIndex(item =>
            item.id === product.id &&
            JSON.stringify(item.variant) === JSON.stringify(variant)
        );

        if (existingItemIndex > -1) {
            this.items[existingItemIndex].quantity += quantity;
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.images.hero, // Store main image for cart display
                quantity: quantity,
                variant: variant // Object with color/size if applicable
            });
        }

        this.save();
        this.showNotification(`Added ${product.name} to cart`);
    },

    remove(itemId, variant = null) {
        this.items = this.items.filter(item =>
            !(item.id === itemId && JSON.stringify(item.variant) === JSON.stringify(variant))
        );
        this.save();
    },

    updateQuantity(itemId, quantity, variant = null) {
        const item = this.items.find(item =>
            item.id === itemId && JSON.stringify(item.variant) === JSON.stringify(variant)
        );

        if (item) {
            item.quantity = parseInt(quantity);
            if (item.quantity <= 0) {
                this.remove(itemId, variant);
            } else {
                this.save();
            }
        }
    },

    clear() {
        this.items = [];
        this.save();
    },

    getCount() {
        return this.items.reduce((total, item) => total + item.quantity, 0);
    },

    getTotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    },

    updateIcon() {
        const badge = document.querySelector('.cart-badge');
        if (badge) {
            const count = this.getCount();
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';
        }
    },

    showNotification(message) {
        // Simple toast notification
        const toast = document.createElement('div');
        toast.className = 'toast fade-in';
        toast.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--color-text-heading);
            color: var(--color-bg);
            padding: 1rem 2rem;
            border-radius: var(--border-radius-md);
            z-index: 1000;
            box-shadow: var(--shadow-lg);
        `;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
};

// Initialize cart on load
document.addEventListener('DOMContentLoaded', () => {
    Cart.init();
});
