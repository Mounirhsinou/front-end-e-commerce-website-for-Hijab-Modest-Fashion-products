/**
 * Product Logic
 * Handles fetching data, filtering, and rendering products.
 */

const Products = {
    all: [],

    async fetchAll() {
        if (this.all.length > 0) return this.all;

        try {
            const response = await fetch('data/products.json');
            if (!response.ok) throw new Error('Failed to load products');
            this.all = await response.json();
            return this.all;
        } catch (error) {
            console.error(error);
            return [];
        }
    },

    async getById(id) {
        const products = await this.fetchAll();
        return products.find(p => p.id === id);
    },

    async getFeatured(limit = 10) {
        const products = await this.fetchAll();
        // For now, just return the first N, or random N
        return products.slice(0, limit);
    },

    renderCard(product) {
        return `
            <article class="card product-card">
                <a href="product-detail.html?id=${product.id}" class="card-image">
                    <img src="${product.images.hero}" alt="${product.name}" loading="lazy">
                </a>
                <div class="card-content">
                    <h3 class="card-title">
                        <a href="product-detail.html?id=${product.id}">${product.name}</a>
                    </h3>
                    <p class="card-price">$${product.price.toFixed(2)}</p>
                    <button class="btn btn-primary mt-sm" onclick="Cart.add({
                        id: '${product.id}',
                        name: '${product.name.replace(/'/g, "\\'")}',
                        price: ${product.price},
                        images: { hero: '${product.images.hero}' }
                    })">
                        Add to Cart
                    </button>
                </div>
            </article>
        `;
    },

    renderGrid(containerId, products) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = products.map(p => this.renderCard(p)).join('');
    }
};
