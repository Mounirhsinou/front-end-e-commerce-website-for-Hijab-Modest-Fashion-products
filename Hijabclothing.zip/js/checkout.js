/**
 * Checkout Logic
 * Handles form validation and mock payment processing.
 */

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('payment-form');
    const payBtn = document.getElementById('pay-btn');
    const errorMsg = document.getElementById('payment-error');
    const checkoutItems = document.getElementById('checkout-items');
    const checkoutTotal = document.getElementById('checkout-total');

    // Inputs
    const cardNumInput = document.getElementById('card-number');
    const cardExpiryInput = document.getElementById('card-expiry');
    const cardCvcInput = document.getElementById('card-cvc');
    const cardBrandIcon = document.getElementById('card-brand');

    // Render Order Summary
    const items = Cart.items;
    if (items.length === 0) {
        window.location.href = 'cart.html'; // Redirect if empty
        return;
    }

    checkoutItems.innerHTML = items.map(item => `
        <div class="flex justify-between mb-sm" style="font-size: var(--font-size-sm);">
            <span>${item.quantity}x ${item.name}</span>
            <span>$${(item.price * item.quantity).toFixed(2)}</span>
        </div>
    `).join('');

    checkoutTotal.textContent = `$${Cart.getTotal().toFixed(2)}`;

    // Input Formatting & Validation
    cardNumInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');

        // Detect Brand
        if (/^4/.test(value)) cardBrandIcon.textContent = 'Visa';
        else if (/^5/.test(value)) cardBrandIcon.textContent = 'MC';
        else cardBrandIcon.textContent = '💳';

        // Format: 0000 0000 0000 0000
        value = value.substring(0, 16);
        const sections = value.match(/.{1,4}/g);
        e.target.value = sections ? sections.join(' ') : value;
    });

    cardExpiryInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        e.target.value = value;
    });

    cardCvcInput.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
    });

    // Form Submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        errorMsg.style.display = 'none';
        payBtn.disabled = true;
        payBtn.textContent = 'Processing...';

        // Basic Validation
        const cardNum = cardNumInput.value.replace(/\s/g, '');
        if (cardNum.length < 13) {
            showError('Invalid card number.');
            return;
        }

        // Mock API Call
        setTimeout(() => {
            // Simulate 90% success rate
            if (Math.random() > 0.1) {
                Cart.clear();
                window.location.href = 'thankyou.html';
            } else {
                showError('Payment declined. Please try again.');
            }
        }, 2000);
    });

    function showError(msg) {
        errorMsg.textContent = msg;
        errorMsg.style.display = 'block';
        payBtn.disabled = false;
        payBtn.textContent = 'Pay Now';
    }
});
