/**
 * Home Page Logic
 * Handles the featured products carousel.
 */

document.addEventListener('DOMContentLoaded', async () => {
    const carouselContainer = document.getElementById('featured-carousel');
    const products = await Products.fetchAll();

    if (!products.length) {
        carouselContainer.innerHTML = '<p>No products found.</p>';
        return;
    }

    let currentIndex = 0;
    const batchSize = 10;
    const rotationInterval = 6000; // 6 seconds
    let intervalId;

    function renderBatch(index) {
        // Calculate start and end indices for the batch
        // We want to cycle through the 30 products
        // 0-9, 10-19, 20-29, then back to 0-9

        const start = (index * batchSize) % products.length;
        const batch = products.slice(start, start + batchSize);

        // If we're at the end and don't have enough items (e.g. 30 items, batch 10, works fine. 
        // If 25 items, batch 10: 0-10, 10-20, 20-25... need to handle wrap around if needed, 
        // but here 30 is divisible by 10 so it's clean).

        // Fade out effect could be done here, but for simplicity we'll just replace innerHTML 
        // with a fade-in animation class on the new elements.

        const html = batch.map(p => Products.renderCard(p)).join('');

        // Apply fade-out to current content if it exists
        if (carouselContainer.children.length > 0 && !carouselContainer.querySelector('.skeleton-loader')) {
            carouselContainer.style.opacity = '0';
            setTimeout(() => {
                carouselContainer.innerHTML = html;
                carouselContainer.style.opacity = '1';
                // Add fade-in class to children for staggered effect if desired
                Array.from(carouselContainer.children).forEach((child, i) => {
                    child.style.animation = `fadeIn 0.5s ease forwards ${i * 0.05}s`;
                    child.style.opacity = '0'; // Start hidden for animation
                });
            }, 300); // Wait for fade out
        } else {
            // First load
            carouselContainer.innerHTML = html;
            Array.from(carouselContainer.children).forEach((child, i) => {
                child.style.animation = `fadeIn 0.5s ease forwards ${i * 0.05}s`;
                child.style.opacity = '0';
            });
        }
    }

    function startRotation() {
        intervalId = setInterval(() => {
            currentIndex++;
            renderBatch(currentIndex);
        }, rotationInterval);
    }

    function stopRotation() {
        clearInterval(intervalId);
    }

    // Initial render
    renderBatch(0);
    startRotation();

    // Pause on hover/focus
    carouselContainer.addEventListener('mouseenter', stopRotation);
    carouselContainer.addEventListener('mouseleave', startRotation);
    carouselContainer.addEventListener('focusin', stopRotation);
    carouselContainer.addEventListener('focusout', startRotation);

    // Add transition style to container for smooth crossfade
    carouselContainer.style.transition = 'opacity 0.3s ease';

    initHeroSlider();
});

function initHeroSlider() {
    const slides = document.querySelectorAll('.hero-slide');
    if (!slides.length) return;

    let currentSlide = 0;
    const slideInterval = 5000; // 5 seconds

    setInterval(() => {
        slides[currentSlide].style.opacity = '0';
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].style.opacity = '1';
    }, slideInterval);
}
